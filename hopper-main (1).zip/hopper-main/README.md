# hopper

**index.js**
Auto register dengan SMSHUB / SMS RU menggunakan email random

**index_delete.js**
Auto register dengan SMSHUB menggunakan email random, setelah register akun tersebut akan dihapus, lalu nomor tersebut dapat digunakan kembali(fresh akun)

**auto_trick.js**
Auto register dengan SMSHUB / SMS RU menggunakan gmail dotrick

**manual.js**
Manual register dengan request email dan nomor (fisik / non fisik)

**manual_delete.js**
Manual register dengan request nomor (fisik/non fisik), setelah berhasil register akun tersebut akan dihapus, lalu nomor tersebut dapat digunakan kembali(fresh akun)

**getReff.js**
Mendapatkan kode referral akun yang sudah dibuat / belum dibuat

**cekSaldo.js**
Cek cash carrot akun yang sudah dibuat
